import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-residences',
  templateUrl: './residences.component.html',
  styleUrls: ['./residences.component.css']
})
export class ResidencesComponent implements OnInit {
  isUpdateResVisible: boolean;
  isDeleteResVisible: boolean;
  isAddResVisible: boolean;
  validateForm!: FormGroup;

  constructor(private modal: NzModalService,
    private notification: NzNotificationService,

    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      address: [null, [Validators.required]],
      name: [null, [Validators.required]],
      resType: [null, [Validators.required]],
      campus: [null, [Validators.required]],


    });
  }

  showUpdateResModal(): void {
    this.isUpdateResVisible = true;
  }

  handleOkUpdateRes(): void {
    this.isUpdateResVisible = false;
    this.notification.create('success','','Successfully updated residence!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  }

  handleCancelUpdateRes(): void {
    this.isUpdateResVisible = false;
  }

  showDeleteResModal(): void {
    this.isDeleteResVisible = true;
  }

  handleOkDeleteRes(): void {
    this.isDeleteResVisible = false;
    this.notification.create('success','','Successfully deleted residence!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  }

  handleCancelDeleteRes(): void {
    this.isDeleteResVisible = false;
  }

  showAddResModal(): void {
    this.isAddResVisible = true;
  }

  handleOkAddRes(): void {
    this.isAddResVisible = false;
    this.notification.create('success','','Successfully added residence!',
    {
      nzStyle: {backgroundColor: 'green',color: 'white' },
      nzClass: ''
    }
  );
  }

  handleCancelAddRes(): void {
    this.isAddResVisible = false;
  }


  
  confirm(): void {
    this.notification.create('success','','Successfully updated residence!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isUpdateResVisible = false;


  }

  confirmAdd(): void {
    this.notification.create('success','','Successfully added residence!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isAddResVisible = false;


  }

  listOfData: any[] = [
    {
      res: "TuksVillage",
      resType:"Mixed Residence",
      campus: "Hatfield",
      address: "Farmers Folly Rd, Koedoespoort 456-Jr, Pretoria, 0186",    
    },
    
   
  ];

}
