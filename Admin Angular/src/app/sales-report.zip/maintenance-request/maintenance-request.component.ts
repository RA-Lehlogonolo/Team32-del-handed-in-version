import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintenance-request',
  templateUrl: './maintenance-request.component.html',
  styleUrls: ['./maintenance-request.component.css']
})
export class MaintenanceRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
