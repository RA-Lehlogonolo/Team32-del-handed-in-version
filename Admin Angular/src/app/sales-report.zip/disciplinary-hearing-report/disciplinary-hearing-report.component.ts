import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disciplinary-hearing-report',
  templateUrl: './disciplinary-hearing-report.component.html',
  styleUrls: ['./disciplinary-hearing-report.component.css']
})
export class DisciplinaryHearingReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
