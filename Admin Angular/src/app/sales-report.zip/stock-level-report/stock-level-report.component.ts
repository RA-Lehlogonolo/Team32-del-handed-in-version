import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-level-report',
  templateUrl: './stock-level-report.component.html',
  styleUrls: ['./stock-level-report.component.css']
})
export class StockLevelReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
