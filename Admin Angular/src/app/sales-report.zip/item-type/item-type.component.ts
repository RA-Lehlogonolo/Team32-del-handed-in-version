import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-item-type',
  templateUrl: './item-type.component.html',
  styleUrls: ['./item-type.component.css']
})
export class ItemTypeComponent implements OnInit {
  validateForm: any;
  isAddItemVisible: boolean;
  isUpdateItemVisible: boolean;
  isDeleteItemVisible: boolean;
  constructor(
    private fb: FormBuilder, 
       private notification: NzNotificationService,
    ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      description: [null, [Validators.required]],
      name: [null, [Validators.required]],
      aType: [null, [Validators.required]],
      campus: [null, [Validators.required]],


    });
  }

  showAddItemModal(): void {
    this.isAddItemVisible = true;

  }

  handleOkAddItem(): void {
    this.isAddItemVisible = false;


  }

  handleCancelAddItem(): void {
    this.isAddItemVisible = false;


  }

  showUpdateItemModal(): void {
    this.isUpdateItemVisible = true;
  }

  handleOkUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  handleCancelUpdateItem(): void {
    this.isUpdateItemVisible = false;
  }

  showDeleteItemModal(): void {
    this.isDeleteItemVisible = true;
  }

  handleOkDeleteItem(): void {
    this.isDeleteItemVisible = false;
    this.notification.create('success','','Successfully deleted item type!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );

  }
  handleCancelDeleteItem(): void {
    this.isDeleteItemVisible = false;
  }


  confirm(): void {
    this.notification.create('success','','Successfully updated item type!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isUpdateItemVisible = false;


  }

  confirmAdd(): void {
    this.notification.create('success','','Successfully added item type!',
      {
        nzStyle: {backgroundColor: 'green',color: 'white' },
        nzClass: ''
      }
    );
    this.isAddItemVisible = false;

  }

  listOfData: any[] = [
    {
    
      itemType: "Protein",
    },
    {


      itemType: "Starch",
    },

    {

      itemType: "Salad",
    },

    {

      itemType: "Vegetable",
    },

       {

  
      itemType: "Sauce",
    },
    {

  
      itemType: "Gravy",
    },
    

  ];
}
